<?php session_start();
include("db.php");


$pid = $_POST['pid'];
$ename=$_POST['ename'];
$dob=$_POST['dob'];
$qual=$_POST['qual'];
$address=$_POST['address'];
 $mobile=$_POST['mobile'];
 $mail=$_POST['mail'];
 $desg=$_POST['desg'];
 $doj=$_POST['doj'];
 $uname=$_POST['uname'];
 $pass=$_POST['pass'];
 $spec=$_POST['spec'];
$q = "insert into employee values($pid,'$ename','$dob','$qual','$address','$mobile','$mail','$desg','$doj','$uname','$pass','$spec')";
mysql_query($q);
header('location:empdetails.php');

?>