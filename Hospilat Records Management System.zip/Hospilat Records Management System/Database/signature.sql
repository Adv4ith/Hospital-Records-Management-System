-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 22, 2017 at 09:10 AM
-- Server version: 5.2.3
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `signature`
--

USE `signature`;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `pid` int(11) NOT NULL,
  `ename` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `qual` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `mailid` varchar(100) NOT NULL,
  `desg` varchar(100) NOT NULL,
  `doj` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `pass` varchar(25) NOT NULL,
  `special` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`pid`, `ename`, `dob`, `qual`, `address`, `mobile`, `mailid`, `desg`, `doj`, `uname`, `pass`, `special`) VALUES
(1, 'venkat', '16-03-1990', 'MD', 'Trichy', '9943920884', 'vijay@gmail.com', 'Doctor', '05-03-2017', 'venkat', 'venkat', 'Heart'),
(2, 'rani', '01-03-1990', 'Nurse', 'trichy', '9965545820', 'rani@gmail.com', 'Staff', '05-03-2017', 'rani', 'rani', 'Nothing'),
(3, 'sathi', '13-03-1990', 'MD', 'trichy', '9943920800', 'sathish@gmail.com', 'Doctor', '07-03-2017', 'sathi', 'sathi', 'Brain');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `tno` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `doe` varchar(100) NOT NULL,
  `dis` varchar(255) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `spec` varchar(100) NOT NULL,
  `etime` varchar(100) NOT NULL,
  `staff` varchar(100) NOT NULL
) ;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`tno`, `pid`, `pname`, `gender`, `age`, `address`, `city`, `pincode`, `phone`, `doe`, `dis`, `dname`, `spec`, `etime`, `staff`) VALUES
(1, 1, 'kabilan', 'Male', '25', 'lalgudi', 'Trichy', '620002', '9003541234', '23-03-2017', 'Body heat', 'venkat', 'Heart', '10.00 AM', 'rani'),
(2, 2, 'arun', 'Male', '25', 'trichy', 'Trichy', '620002', '9003541211', '21-03-2017', 'Fever', 'venkat ', 'Heart', '11.00 AM', 'rani'),
(3, 3, 'Muruga', 'Male', '25', 'Eroad', 'Trichy', '620002', '9003541255', '20-03-2017', 'Fever', 'sathi ', 'Brain', '11.00 AM', 'rani');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `tno` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `doe` varchar(100) NOT NULL,
  `dis` varchar(255) NOT NULL,
  `dname` varchar(100) NOT NULL,
  `etime` varchar(100) NOT NULL,
  `t1` varchar(100) NOT NULL,
  `t2` varchar(100) NOT NULL,
  `t3` varchar(100) NOT NULL,
  `t4` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`tno`, `pid`, `pname`, `gender`, `age`, `address`, `city`, `pincode`, `phone`, `doe`, `dis`, `dname`, `etime`, `t1`, `t2`, `t3`, `t4`, `status`) VALUES
(1, 1, 'kabilan', 'Male', '25', 'lalgudi', 'Trichy', '620002', '9003541234', '23-03-2017', 'Body heat', 'venkat', '10.00 AM', 'Yes', 'Yes', 'No', 'No', 'Waiting'),
(1, 1, 'kabilan', 'Male', '25', 'lalgudi', 'Trichy', '620002', '9003541234', '23-03-2017', 'Body heat', 'venkat', '10.00 AM', 'Yes', 'No', 'No', 'Yes', 'Waiting'),
(3, 3, 'Muruga', 'Male', '25', 'Eroad', 'Trichy', '620002', '9003541255', '20-03-2017', 'Fever', 'sathi ', '11.00 AM', 'Yes', 'Yes', 'Yes', 'Yes', 'Waiting');
