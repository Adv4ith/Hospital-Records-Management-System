<?php session_start();
include("db.php");
$q = mysql_query("select max(pid) as id1 from patient");
$data= mysql_fetch_assoc($q);
$pid = $data['id1'] + 1;
?>

<!DOCTYPE html> 
<html>

<head>
  <title>SECURE SIGNATURE SCHEME WITH MULTIPLE AUTHORITIES FOR BLOCKCHAIN IN EHR</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
  <link rel="stylesheet" type="text/css" href="tcal.css" />
    <script type="text/javascript" src="tcal.js"></script> 
  <style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-size: large;
}
-->
  </style>
  <script type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body>
  <div id="main">
    <header>
	  <div id="banner">
	    <div id="welcome">
	      <h3> 
<span> SECURE SIGNATURE SCHEME WITH MULTIPLE AUTHORITIES FOR BLOCKCHAIN IN EHR </span></h3>
	    </div><!--close welcome-->
	    <div id="welcome_slogan">
	      <h3>&nbsp;</h3>
	    </div><!--close welcome_slogan-->			
	  </div><!--close banner-->
    </header>

	<nav>
	  <div id="menubar">
        <ul id="nav">
          <li class="current"><a href="index.html">Home</a></li>         
          <li><a href="patient.php">Patient Entry</a></li>         
          <li><a href="patientdetails.php">Patient Details</a></li>
		  <li><a href="changepass.php">Change Password</a></li>
		  <li><a href="index.html">Sign out</a></li>
        </ul>
      </div><!--close menubar-->	
    </nav>	
    
	<div id="site_content">	

      <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="900" height="250" src="images/1.jpg"   /></li>
          <li><img width="900" height="250" src="images/3.jpg"  /></li>
		   <li><img width="900" height="250" src="images/4.jpg"  /></li>
		    <li><img width="900" height="250" src="images/5.jpg"  /></li>
        </ul> 
	  </div>	
	
	  <div id="content">
        
		    
		  <br>
		   
           	
          <table width="100%" border="0" height="500px">
  <tr>
    <td>
	<table width="100%" border="0" height="500px">
  <tr>
    <td width="25%" align="center">
	<img src="images/azz.jpeg" width="150" height="150"><br>
	<br>
	<img src="images/images[2].jpg" width="150" height="150"><br>
	<br>
	<img src="images/MedicalResearch.jpg" width="150" height="150"><br>
	<br>
	</td>
    <td>
	<center>
	<table width="100%" border="0" background="images/background.jpg" class="tb">
	<tr>
	<td align="right">
	
	<h1 style="font-size:25px; color:#FF33CC"> Welcome : <?php  echo $uname=$_SESSION['ename']; ?> </h1>	
	</td>
	</tr>
	<tr>
	<td height="450px">
	<form name="f1" action="patientadd.php" method="post">
	<table width="100%" border="0"  >
   
</table> 
    <table width="100%" border="0" cellspacing="10">
      <tr>
        <td colspan="4"><div align="center" class="style1">PATIENT ENTRY </div></td>
        </tr>
      <tr>
        <td>Doctor Name </td>
        <td>
		<select name="dname" id="dname" class="txt" style="height:30px" onChange="MM_jumpMenu('parent',this,0)">
		<option>Select Doctor</option>
		<?php
		  
		  $q5=mysql_query("select * from employee where desg='Doctor'");
					while($r=mysql_fetch_assoc($q5))
							{
echo "<option value=patient.php?id=".$r['pid'].">".$r['ename']."</option>";
								}
							echo	$id=$_REQUEST['id'];
								
								  ?>
                </select>
				<br>
				
				<?php $result = mysql_query("SELECT *FROM employee where pid='$id' ");
$row1= mysql_fetch_array($result);
?>	
				
				
				<input name="dname1" id="dname1"  type="text" class="txt" value="<?php echo $row1[ename]; ?> ">
				 	</td>
        <td>Specialzation</td>
        <td><input name="spec" type="text" id="spec" class="txt" value="<?php echo $row1[special]; ?>"></td>
      </tr>
      <tr>
        <td>Patient ID </td>
        <td><label>
          <input name="pid" type="text" id="pid" class="txt" value="<?php echo $pid; ?>">
        </label></td>
        <td>Date of Entry </td>
        <td>  <input name="doe" type="text" class="tcal" id="doe"  size="15"   style="width:150px; height:25px;"/></td>
      </tr>
      <tr>
        <td>Patinet Name </td>
        <td><label>
          <input name="pname" type="text" id="pname" class="txt"><input name="staff" type="hidden" id="staff" value="<?php echo $uname; ?>"/>

        </label></td>
        <td><strong>Disease</strong></td>
        <td><input name="dis" type="text" id="dis" class="txt"></td>
      </tr>
      <tr>
        <td>Gender</td>
        <td><label>
          <select name="gender" id="gender" class="txt" style="height:30px">
		  <option>Select Gender</option>
		  <option>Male</option>
		  <option>Female</option>
          </select>
        </label></td>
        <td>Time</td>
        <td><input name="etime" type="text" id="etime" class="txt"></td>
      </tr>
	   
      <tr>
        <td>Age</td>
        <td><label>
          <input name="age" type="text" id="age" class="txt">
        </label></td>
        <td>Token No </td>
        <td><input name="tno" type="text" id="tno" class="txt"></td>
      </tr>
      <tr>
        <td>Address</td>
        <td><label>
          <textarea name="address" id="address" class="txt1"></textarea>
        </label></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>City</td>
        <td><select name="city" id="city" class="txt" style="height:30px">
		<option>Select City</option>
		  <option>Trichy</option>
		  <option>Chennai</option>
		  <option>Eroad</option>
		  <option>Coimbatore</option>
		  <option>Madurai</option>
		  <option>Salem</option>
                </select></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Pincode</td>
        <td><input name="pincode" type="text" id="pincode" class="txt"></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Phone</td>
        <td><input name="phone" type="text" class="txt" id="phone"></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp; </td>
        <td>&nbsp;</td>
        <td colspan="2"> 
          <input type="submit" name="Submit" value="Submit" class="btn">
		       <input type="Reset" name="Submit" value="Clear" class="btn">       </td>
        </tr>
    </table>
	</form>
 

	
	</td>
	</tr>
	
	</table>
	
	
	
	
	</td>
	 
  </tr>
</table>

	
	
	
	
	
	
	
	
	
	
	
	</td>
  </tr>
</table>

		  
		</div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
  </div><!--close main-->
  
    <footer>
	   www.Electronic Health Records.com

    </footer>

  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>
