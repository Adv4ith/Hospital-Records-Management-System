<?php session_start();
include("db.php");

$tno = $_POST['tno'];
$pid = $_POST['pid'];
$pname=$_POST['pname'];
$gender=$_POST['gender'];
$age=$_POST['age'];
$address=$_POST['address'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
$phone=$_POST['phone'];
$doe=$_POST['doe'];
$dis=$_POST['dis'];
$dname=$_POST['dname'];
$etime=$_POST['etime'];
$staff=$_POST['staff'];
$c1=$_POST['c1'];
$c2=$_POST['c2'];
$c3=$_POST['c3'];
$c4=$_POST['c4'];

if($c1!="")
{
echo $c1="Yes";
}
else
{
echo $c1="No";

}
if($c2!="")
{
echo $c2="Yes";
}
else
{
echo $c2="No";

}
if($c3!="")
{
echo $c3="Yes";
}
else
{
echo $c3="No";

}
if($c4!="")
{
echo $c4="Yes";
}
else
{
echo $c4="No";

}

$q = "insert into test values('$tno',$pid,'$pname','$gender','$age','$address','$city','$pincode','$phone','$doe','$dis','$dname','$etime','$c1','$c2','$c3','$c4','Waiting')";
mysql_query($q);

header("location:dpatientdetails.php");
 
?>