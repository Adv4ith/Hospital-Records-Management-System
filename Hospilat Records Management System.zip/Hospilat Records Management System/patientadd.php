<?php session_start();
include("db.php");

$tno = $_POST['tno'];
$pid = $_POST['pid'];
$pname=$_POST['pname'];
$gender=$_POST['gender'];
$age=$_POST['age'];
$address=$_POST['address'];
$city=$_POST['city'];
$pincode=$_POST['pincode'];
$phone=$_POST['phone'];
$doe=$_POST['doe'];
$dis=$_POST['dis'];
$dname=$_POST['dname1'];
$spec=$_POST['spec'];

$etime=$_POST['etime'];
$staff=$_POST['staff'];
$q = "insert into patient values('$tno',$pid,'$pname','$gender','$age','$address','$city','$pincode','$phone','$doe','$dis','$dname','$spec','$etime','$staff')";
mysql_query($q);
echo "success";
header('location:patientdetails.php');

?>