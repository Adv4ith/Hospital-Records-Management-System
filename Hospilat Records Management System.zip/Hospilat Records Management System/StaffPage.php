<?php session_start();
?>
<!DOCTYPE html> 
<html>

<head>
  <title>SECURE SIGNATURE SCHEME WITH MULTIPLE AUTHORITIES FOR BLOCKCHAIN IN EHR</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <!-- modernizr enables HTML5 elements and feature detects -->
  <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
  <div id="main">
    <header>
	  <div id="banner">
	    <div id="welcome">
	      <h3> 
<span> SECURE SIGNATURE SCHEME WITH MULTIPLE AUTHORITIES FOR BLOCKCHAIN IN EHR </span></h3>
	    </div><!--close welcome-->
	    <div id="welcome_slogan">
	      <h3>&nbsp;</h3>
	    </div><!--close welcome_slogan-->			
	  </div><!--close banner-->
    </header>

	<nav>
	  <div id="menubar">
        <ul id="nav">
          <li class="current"><a href="index.html">Home</a></li>         
          <li><a href="patient.php">Patient Entry</a></li>         
          <li><a href="patientdetails.php">Patient Details</a></li>
		  <li><a href="changepass.php">Change Password</a></li>
		  <li><a href="index.html">Sign out</a></li>
        </ul>
      </div><!--close menubar-->	
    </nav>	
    
	<div id="site_content">	

      <div class="slideshow">
	    <ul class="slideshow">
          <li class="show"><img width="900" height="250" src="images/1.jpg"   /></li>
          <li><img width="900" height="250" src="images/3.jpg"  /></li>
		   <li><img width="900" height="250" src="images/4.jpg"  /></li>
		    <li><img width="900" height="250" src="images/5.jpg"  /></li>
        </ul> 
	  </div>	
	
	  <div id="content">
        
		    
		  <br>
		   
           	
          <table width="100%" border="0" height="500px">
  <tr>
    <td>
	<table width="100%" border="0" height="500px">
  <tr>
    <td width="25%" align="center">
	<img src="images/azz.jpeg" width="150" height="150"><br>
	<br>
	<img src="images/images[2].jpg" width="150" height="150"><br>
	<br>
	<img src="images/MedicalResearch.jpg" width="150" height="150"><br>
	<br>
	</td>
    <td>
	<center>
	<table width="100%" border="0" background="images/background.jpg" class="tb">
	<tr>
	<td align="right">
	
	<h1 style="font-size:25px; color:#FF33CC"> Welcome : <?php  echo $_SESSION['ename']; ?> </h1>	
	</td>
	</tr>
	<tr>
	<td height="450px">
	<form name="f1" action="login.php" method="post">
	<table width="100%" border="0" cellspacing="15">
   
</table> 
</form>
 

	
	</td>
	</tr>
	
	</table>
	
	
	
	
	</td>
	 
  </tr>
</table>

	
	
	
	
	
	
	
	
	
	
	
	</td>
  </tr>
</table>

		  
		</div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
  </div><!--close main-->
  
    <footer>
	   www.Electronic Health Records.com

    </footer>

  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/image_slide.js"></script>
  
</body>
</html>
