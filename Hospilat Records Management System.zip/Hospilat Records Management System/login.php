<?php session_start();
include("db.php");
?>

<?php

echo $utype=$_POST["select"];
echo $uname=$_POST["txtuname"];
echo $pass=$_POST["txtpwd"];

if ($utype=="Admin")
{
  if($uname=="admin" && $pass="admin")
	{
	 header("location:AdminPage.php");
	}
}
else if ($utype=="Doctor")
{
   echo "Doctor";
   
   $result=mysql_query("select * from employee where uname='$uname' and pass='$pass'");
    $r=mysql_fetch_array($result);
	if($r['uname']==$uname && $r['pass']==$pass)
	{
	echo $_SESSION['name']=$r['ename'];
	$_SESSION['uname']=$r['uname'];
	$_SESSION['email']=$r['email'];
	header('location:DoctorPage.php');
	}
    else
    {
     header('location:wronglogin.php');
    }
}

else if ($utype=="Staff")
{

   echo "User";
   $result=mysql_query("select * from employee where uname='$uname' and pass='$pass'");
   $r=mysql_fetch_array($result);
	if($r['uname']==$uname && $r['pass']==$pass)
	{
	$_SESSION['ename']=$r['ename'];
	$_SESSION['uname']=$r['uname'];
	$_SESSION['email']=$r['email'];
	header('location:StaffPage.php');
	}
    else
    {
     header('location:wronglogin.php');
    }
	
	
}







?>
